export const siteTexts = {
  hero: {
    badge: "SUN Mentoring School",
    title: {
      main: "Skuteczne praktyki, dzięki którym",
      accent: "zaczniesz mówić po angielsku",
      end: "bez stresu"
    },
    subtitle: "Aktywuj swój angielski już pierwszego dnia – bez blokady i bez dużych inwestycji",
    cta: "Kup teraz za 47 PLN",
    guarantee: "💳 Bezpieczna płatność • ⚡ Natychmiastowy dostęp • 🔒 Gwarancja satysfakcji"
  },
  
  problem: {
    title: "Czy to brzmi znajomo?",
    issues: [
      "Uczyłaś się latami, ale w praktyce nie używasz angielskiego wcale.",
      "Widzisz oferty pracy z 'must have English' i czujesz dreszcze.",
      "W głowie pojawia się czarna dziura, gdy musisz coś powiedzieć.",
      "Wstydzisz się, bo 'powinnaś już umieć'."
    ],
    solution: {
      calm: "spokojnie",
      text: "Jeśli czujesz, że to o Tobie – {calm}. To nie brak talentu.",
      emphasis: "Brakuje Ci kontaktu z żywym językiem."
    }
  },
  
  solution: {
    title: "Dlaczego stworzyłam Aktywatory?",
    description: "Zestaw prostych, szybkich praktyk, które {emphasis}aktywują Twój mózg{/emphasis}. Szkoła i podręczniki tego nie dają. To metoda na wyjście z kołowrotka stresu i wstydu.",
    features: {
      simple: {
        title: "Proste",
        description: "Każda praktyka to max 5-10 minut dziennie"
      },
      pleasant: {
        title: "Przyjemne", 
        description: "Nie musisz się męczyć – używaj tego, co lubisz"
      },
      effective: {
        title: "Skuteczne",
        description: "Pierwsze efekty zobaczysz już po tygodniu"
      }
    }
  },
  
  curriculum: {
    title: "Co znajdziesz w programie?",
    subtitle: "6 filmów VOD + bonusy, które odmienią Twój angielski",
    modules: [
      {
        title: "VOD 1: Aktywatory Słuchania",
        description: "Filmy, piosenki, reelsy jako Twoja codzienność językowa",
        duration: "15 min"
      },
      {
        title: "VOD 2: Aktywatory Mówienia",
        description: "1-minutowe wyzwania, shadowing, dialogi dla pewności siebie",
        duration: "18 min"
      },
      {
        title: "VOD 3: Aktywatory Czytania",
        description: "Social media, newsy – czytaj to, co Cię interesuje",
        duration: "12 min"
      },
      {
        title: "VOD 4: Aktywatory Pisania",
        description: "Krótkie wiadomości i wykorzystanie AI w nauce",
        duration: "14 min"
      },
      {
        title: "VOD 5: Boostery pewności siebie",
        description: "Myślenie po angielsku i gry mentalne bez stresu",
        duration: "20 min"
      },
      {
        title: "VOD 6: My English Journey",
        description: "Moja historia – jak przeszłam tę samą drogę",
        duration: "16 min"
      }
    ]
  },
  
  bonuses: {
    title: "Bonusy wartościowe jak cały kurs",
    specialBonus: {
      title: "🎁 BONUS dla pierwszych 20 osób",
      description: "{emphasis}Talk & Chill Room{/emphasis} – dostęp na 30 dni do naszej społeczności, gdzie ćwiczysz mówienie w bezpiecznej atmosferze"
    },
    regularBonuses: [
      {
        title: "E-book z planem treningowym",
        description: "Gotowy plan na 30 dni – wystarczy, że będziesz go realizować"
      },
      {
        title: "Checklista z aktywatorami",
        description: "Wszystkie praktyki w jednym miejscu do codziennego wykorzystania"
      },
      {
        title: "Zestaw afirmacji (audio + PDF)",
        description: "Pozytywne przekonania, które zmienią Twój mindset językowy"
      }
    ]
  },
  
  author: {
    title: "Kim jestem i dlaczego możesz mi zaufać?",
    name: "Natalia Chas",
    description: "Nauczycielka, pedagog i coach z pasją do języków i rozwoju osobistego.",
    credentials: [
      "Mieszkałam 8 lat w UK – znam obie strony: naukę i życie w języku",
      "Teraz mieszkam w Hiszpanii, gdzie codziennie łączę języki i kultury",
      "Łączę mentoring, wiedzę akademicką i psychologię – bo nauka to nie tylko gramatyka",
      "Pomagam kobietom przełamać barierę językową i uwierzyć we własne możliwości"
    ]
  },
  
  testimonials: {
    title: "Co mówią moje uczestniczki?",
    reviews: [
      {
        text: "Zajęcia indywidualne od pół roku. Wzrost pewności siebie już po kilku godzinach!",
        author: "Malwina"
      },
      {
        text: "Bariera językowa ze szkoły przełamana w 3 miesiące. To działa!",
        author: "Agata"
      },
      {
        text: "Od zera i strachu przed 'hello' do awansu na stanowisko Andona w UK!",
        author: "Ania's Story",
        featured: true
      }
    ]
  },
  
  targetAudience: {
    title: "Dla kogo jest ten program?",
    forWho: {
      title: "Dla kogo?",
      items: [
        "Uczysz się lub uczyłaś angielskiego, ale w praktyce nie mówisz",
        "Chcesz prostej rutyny bez godzin studiowania",
        "Potrzebujesz pewności siebie w mówieniu",
        "Wracasz do angielskiego po przerwie",
        "Szukasz metody, która łączy naukę z przyjemnością"
      ]
    },
    notForWho: {
      title: "Dla kogo NIE?",
      items: [
        "Dzieci poniżej 16 roku życia",
        "Osoby na poziomie C2 / Native speakers",
        "Osoby szukające kursu gramatycznego",
        "Osoby, które nie będą robić ćwiczeń",
        "Osoby oczekujące magicznej formuły bez pracy"
      ]
    }
  },
  
  pricing: {
    title: "Zacznij dziś za",
    price: "47 PLN",
    subtitle: "Zamiast płacić tysiące za długie kursy – zainwestuj w metodę, która działa",
    packageTitle: "Co dostajesz w pakiecie?",
    packageItems: [
      "6 filmów VOD z aktywatorami (łącznie ~95 minut)",
      "Dostęp na 3 lata do wszystkich materiałów",
      "E-book z 30-dniowym planem treningowym",
      "Checklista aktywatorów do wydruku",
      "Zestaw afirmacji (audio + PDF)",
      "BONUS: Talk & Chill Room na 30 dni (dla pierwszych 20 osób)"
    ],
    value: {
      original: "397 PLN",
      current: "47 PLN"
    },
    cta: "Dołączam do programu English Activator",
    guarantee: "💳 Bezpieczna płatność • 🔒 Faktura automatyczna • ⚡ Dostęp natychmiast"
  },
  
  faq: {
    title: "Najczęściej zadawane pytania",
    questions: [
      {
        question: "Jak długo mam dostęp do kursu?",
        answer: "Masz dostęp przez pełne 3 lata od momentu zakupu. To wystarczająco dużo czasu, żeby wrócić do materiałów wielokrotnie i utrwalić nawyki."
      },
      {
        question: "Czy dostanę fakturę?",
        answer: "Tak! Faktura jest generowana automatycznie po dokonaniu płatności. Otrzymasz ją na podany adres email."
      },
      {
        question: "Dla jakiego poziomu jest ten kurs?",
        answer: "Kurs jest idealny dla poziomów A1 do C1. Jeśli zaczynasz od zera (A0), również możesz skorzystać, ale niektóre praktyki będą wymagały więcej czasu i cierpliwości."
      },
      {
        question: "Ile czasu dziennie muszę poświęcić?",
        answer: "Aktywatory są zaprojektowane tak, żeby zajmowały 5-15 minut dziennie. Możesz robić więcej, jeśli chcesz, ale nawet regularne 10 minut dziennie da Ci zauważalne efekty."
      },
      {
        question: "Co jeśli nie będzie mi to pasować?",
        answer: "Jeśli w ciągu pierwszych 14 dni stwierdzisz, że program nie jest dla Ciebie, skontaktuj się ze mną, a zwrócę Ci pieniądze. Bez pytań."
      },
      {
        question: "Czy to zastąpi mi kurs angielskiego?",
        answer: "Aktywatory to nie jest pełny kurs gramatyczny. To zestaw praktyk, które uzupełniają naukę i pomagają wyjść z pętli \"wiem, ale nie używam\". Jeśli potrzebujesz systematycznej nauki od podstaw, polecam połączenie aktywatorów z kursem lub zajęciami indywidualnymi."
      }
    ]
  },
  
  finalCta: {
    title: "Gotowa, żeby aktywować swój angielski?",
    subtitle: "Dołącz do kobiet, które już przełamały barierę językową i mówią po angielsku z pewnością siebie. Twoja kolej na zmianę!",
    button: "Zaczynam za 47 PLN"
  },
  
  footer: {
    company: "SUN Mentoring School",
    copyright: "© 2025 SUN Mentoring Natalia Chas. Wszelkie prawa zastrzeżone.",
    links: {
      terms: "Regulamin",
      privacy: "Polityka Prywatności"
    }
  }
};